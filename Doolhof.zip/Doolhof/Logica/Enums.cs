﻿namespace Global {
    public enum Direction {
        up,
        down,
        left,
        right
    }

}
