﻿using Global;
using Logic;
using Logica;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Shapes;

namespace Doolhof {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        private Maze maze;
        private Button lastClickedButton;
        public MainWindow() {
            InitializeComponent();

        }

        /// <summary>
        /// Main menu interface
        /// Sources:
        /// https://www.dotnetperls.com/keydown-wpf
        /// https://stackoverflow.com/questions/4773632/how-do-i-restart-a-wpf-application
        /// https://stackoverflow.com/questions/728432/how-to-programmatically-click-a-button-in-wpf
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_KeyDown(object sender, KeyEventArgs e) {
            if (e.Key == Key.R) {
                if (lastClickedButton != null) {
                    lastClickedButton.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
                }
            }

            if (e.Key == Key.E) {
                InitializeComponent();
                Debug.WriteLine("restarting");
                System.Windows.Forms.Application.Restart();
                System.Windows.Application.Current.Shutdown();

            }
        }


        /// <summary>
        /// Generate wallsCreationAlgoritm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void wallButton_Click(object sender, RoutedEventArgs e) {
            lastClickedButton = wallCreationButton;
            int.TryParse(sizeLabel.Text, out int inputValue);
            maze = new Maze(inputValue, inputValue);
            maze.GenerateGrid(Color.Black);
            WallsCreationAlgoritm algo = new WallsCreationAlgoritm(maze);
            algo.Generate();
            GenerateVisualGrid(algo.maze);
        }


        /// <summary>
        /// Generate DepthFirst Algoritm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void depthButton_Click(object sender, RoutedEventArgs e) {
            lastClickedButton = depthFirstButton;
            int.TryParse(sizeLabel.Text, out int inputValue);
            maze = new Maze(inputValue, inputValue);
            maze.GenerateGrid(Color.Red);
            DepthFirstAlgoritm algo = new DepthFirstAlgoritm(maze);

            algo.Generate();
            GenerateVisualGrid(algo.maze);

        }

        /// <summary>
        /// Generate BinaryTree Algoritm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BinaryTreeButton_Click(object sender, RoutedEventArgs e) {
            lastClickedButton = binaryTreeButton;
            int.TryParse(sizeLabel.Text, out int inputValue);
            maze = new Maze(inputValue, inputValue);
            maze.GenerateGrid(Color.Red);
            BinaryTreeAlgoritm algo = new BinaryTreeAlgoritm(maze);
            algo.Generate();
            GenerateVisualGrid(algo.maze);
        }

        /// <summary>
        /// Draw the static maze when the staticButton is pressed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StaticButton_Click(object sender, RoutedEventArgs e) {
            lastClickedButton = staticButton;
            int.TryParse(sizeLabel.Text, out int inputValue);
            maze = new Maze(20, 20);
            maze.GenerateGrid(Color.Black);
            StaticMazeGenerator mazeGenerator = new StaticMazeGenerator();
            mazeGenerator.GenerateStaticMaze();
            maze = mazeGenerator.maze;
            GenerateVisualGrid(mazeGenerator.maze);

        }

        /// <summary>
        /// Change maze size
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LegthTextBox_TextChanged(object sender, TextChangedEventArgs e) {
            if (int.TryParse(sizeLabel.Text, out int inputValue)) {
                if (inputValue >= 10 && inputValue <= 150) {
                    errorLabel = new Label();
                    errorLabel.Visibility = Visibility.Collapsed;
                }
                else {
                    errorLabel.Visibility = Visibility.Visible;
                }
            }
            else {
                errorLabel.Visibility = Visibility.Visible;
            }
        }


        /// <summary>
        /// Generate the grid object
        /// </summary>
        /// <param name="maze"></param>
        private void GenerateVisualGrid(Maze maze) {
            int rowCount = maze.height;
            int columnCount = maze.length;
            mazeGrid.RowDefinitions.Clear();
            mazeGrid.ColumnDefinitions.Clear();

            for (int i = 0; i < rowCount; i++) {
                mazeGrid.RowDefinitions.Add(new RowDefinition());
            }

            for (int j = 0; j < columnCount; j++) {
                mazeGrid.ColumnDefinitions.Add(new ColumnDefinition());
            }

            for (int i = 0; i < rowCount; i++) {
                for (int j = 0; j < columnCount; j++) {
                    Cell cell = maze.cels[j, i];
                    GenerateText(i, j, cell);
                    GenerateBorders(i, j, cell);
                }
            }

        }

        /// <summary>
        /// Generates and visualises a textblock with the id of the corresponsing cell 
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <param name="cell"></param>
        private void GenerateText(int i, int j, Cell cell) {
            TextBlock textBlock = new TextBlock {
                Text = cell.id.ToString(),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,


            };

            Grid.SetRow(textBlock, i);
            Grid.SetColumn(textBlock, j);
            mazeGrid.Children.Add(textBlock);

        }

        /// <summary>
        /// Draw the ball as a 2D circle on the grid.
        /// </summary>
        /// <param name="ball"></param>
        private void DrawBall(Ball ball) {
            int rowCount = maze.height;
            int columnCount = maze.length;

            double cellWidth = mazeGrid.ActualWidth / columnCount;
            double cellHeight = mazeGrid.ActualHeight / rowCount;

            Ellipse ellipse = new Ellipse {
                Width = cellWidth,
                Height = cellHeight,
                Fill = ToBrush(Color.Blue)
            };

            Grid.SetRow(ellipse, (int)Math.Ceiling(ball.y));
            Grid.SetColumn(ellipse, (int)Math.Ceiling(ball.x));

            mazeGrid.Children.Add(ellipse);
        }





        /// <summary>
        /// This conversion methode is taken from stackoverflow
        /// </summary>
        /// <href = https://stackoverflow.com/a/33523743></href>
        /// <param name="color"></param>
        /// <returns></returns>
        private System.Windows.Media.Brush ToBrush(System.Drawing.Color color) {
            return new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(color.A, color.R, color.G, color.B));
        }

        /// <summary>
        /// Generates & visualises the borders of the grid cells
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <param name="cell"></param>
        private void GenerateBorders(int i, int j, Cell cell) {
            Border border = new Border {
                BorderThickness = new Thickness(1),
            };
            if (!cell.walls[0]) // Top wall
                {
                border.BorderThickness = new Thickness(border.BorderThickness.Left, 0, border.BorderThickness.Right, border.BorderThickness.Bottom);
            }
            if (!cell.walls[1]) // Right wall
            {
                border.BorderThickness = new Thickness(border.BorderThickness.Left, border.BorderThickness.Top, 0, border.BorderThickness.Bottom);
            }
            if (!cell.walls[2]) // Bottom wall
            {
                border.BorderThickness = new Thickness(border.BorderThickness.Left, border.BorderThickness.Top, border.BorderThickness.Right, 0);
            }
            if (!cell.walls[3]) // Left wall
            {
                border.BorderThickness = new Thickness(0, border.BorderThickness.Top, border.BorderThickness.Right, border.BorderThickness.Bottom);
            }
            border.BorderBrush = ToBrush(cell.color);
            border.Background = ToBrush(cell.color);
            Grid.SetRow(border, i);
            Grid.SetColumn(border, j);
            Grid.SetRowSpan(border, 1);
            Grid.SetColumnSpan(border, 1);
            mazeGrid.Children.Add(border);
            DrawBall(maze.ball);



        }
    }
}
