﻿using System.Windows;

namespace Wpf_3D {
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application {
    }
}
